<?php
//$_[''] = '';

// Yandex Translate
$_['attention_yandex_translate_401'] = 'Невірний ключ API';
$_['attention_yandex_translate_402'] = 'Ключ API заблоковано';
$_['attention_yandex_translate_403'] = 'Ви перевищили добове обмеження на кількість запитів';
$_['attention_yandex_translate_404'] = 'Ви перевищили добове обмеження на обсяг перекладеного тексту';
$_['attention_yandex_translate_413'] = 'Перевищено максимально допустимий розмір тексту';
$_['attention_yandex_translate_422'] = 'Текст не може бути переведений';
$_['attention_yandex_translate_501'] = 'Заданий напрямок перекладу не підтримується';
?>