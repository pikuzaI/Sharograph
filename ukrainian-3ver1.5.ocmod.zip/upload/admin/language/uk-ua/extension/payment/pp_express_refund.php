<?php
// Heading
$_['heading_title'] = 'Повернення транзакції';

// Text
$_['text_pp_express'] = 'PayPal Експрес-платежі';
$_['text_current_refunds'] = 'Повернення вже виконаний для даної операції. Максимальна сума повернення ';
$_['text_refund'] = 'Повернення';

// Entry
$_['entry_transaction_id'] = 'ID транзакції';
$_['entry_full_refund'] = 'Повний повернення';
$_['entry_amount'] = 'Сума';
$_['entry_message'] = 'Повідомлення';

// Button
$_['button_refund'] = 'Оформити повернення';

// Error
$_['error_partial_amt'] = 'Ви повинні ввести частину суми';
$_['error_data'] = 'Немає даних';