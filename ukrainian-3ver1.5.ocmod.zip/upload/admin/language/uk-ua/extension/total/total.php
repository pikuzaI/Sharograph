<?php
// Heading
$_['heading_title'] = 'Сума';

// Text
$_['text_total'] = 'Враховувати в замовленні';
$_['text_success'] = 'Налаштування успішно змінено!';
$_['text_edit'] = 'Налаштування';

// Entry
$_['entry_status'] = 'Статус';
$_['entry_sort_order'] = 'Порядок сортування';

// Error
$_['error_permission'] = 'У Вас немає прав для управління даним модулем!';