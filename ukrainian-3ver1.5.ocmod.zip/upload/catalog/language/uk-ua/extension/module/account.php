<?php
// Heading
$_['heading_title'] = 'Особистий кабінет';

// Text
$_['text_register'] = 'Реєстрація';
$_['text_login'] = 'Вхід';
$_['text_logout'] = 'Вихід';
$_['text_forgotten'] = 'Забули пароль?';
$_['text_account'] = 'Моя інформація';
$_['text_edit'] = 'Змінити контактну інформацію';
$_['text_password'] = 'Пароль';
$_['text_address'] = 'Адресна книга';
$_['text_wishlist'] = 'Закладки';
$_['text_order'] = 'Історія замовлень';
$_['text_download'] = 'Файли для скачування';
$_['text_reward'] = 'Бонусні бали';
$_['text_return'] = 'Повернення';
$_['text_transaction'] = 'Історія транзакцій';
$_['text_newsletter'] = 'E-Mail розсилка';
$_['text_recurring'] = 'Регулярні платежі';