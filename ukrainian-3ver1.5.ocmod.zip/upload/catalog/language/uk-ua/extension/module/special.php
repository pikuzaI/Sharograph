<?php
// Heading
$_['heading_title'] = 'Акції';

// Text
$_['text_tax'] = 'Без ПДВ:';