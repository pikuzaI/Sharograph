<?php
$_['text_total'] = 'Разом';