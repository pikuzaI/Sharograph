<?php
// Heading
$_['heading_title'] = 'Партнерський розділ';

// Text
$_['text_account'] = 'Кабінет Партнера';
$_['text_my_account'] = 'Мій обліковий запис';
$_['text_my_tracking'] = 'Мої реферали';
$_['text_my_transactions'] = 'Історія виплат';
$_['text_edit'] = 'Редагувати обліковий запис';
$_['text_password'] = 'Змінити пароль';
$_['text_payment'] = 'Змінити платіжні реквізити';
$_['text_tracking'] = 'Реферальний код';
$_['text_transaction'] = 'Показати історію виплат';